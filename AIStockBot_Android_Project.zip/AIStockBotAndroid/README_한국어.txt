AI STOCK BOT - 안드로이드 앱 프로젝트

중요: 이 파일은 바로 설치하는 APK가 아니라 APK를 빌드할 수 있는 Android Studio 프로젝트입니다.
현재 실행 화면은 데모이며 실시간 주가/API/주문/자동매매는 연결되어 있지 않습니다.

APK 만들기(PC 필요):
1. Android Studio 설치
2. 이 ZIP 압축 해제 후 Android Studio에서 폴더 열기
3. Gradle Sync 완료
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. app/build/outputs/apk/debug/app-debug.apk 생성
6. APK를 휴대폰으로 옮겨 설치

GitHub Actions 자동 빌드:
1. GitHub 새 저장소 생성 후 프로젝트 파일 업로드
2. Actions 탭에서 Android APK workflow 실행
3. 실행 결과의 Artifacts에서 apk-debug 다운로드
4. 휴대폰에서 다운로드한 APK 설치

보안/투자:
- 앱에 증권사 App Key/Secret을 입력하거나 포함하지 마세요.
- 이 프로젝트에는 실계좌 주문 기능이 없습니다.
- 샘플 종목 점수는 가짜 데이터이며 추천이 아닙니다.
